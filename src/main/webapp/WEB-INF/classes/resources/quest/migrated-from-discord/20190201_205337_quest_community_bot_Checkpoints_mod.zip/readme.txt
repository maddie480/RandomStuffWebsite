=============================================
Syst�me de checkpoints : tutoriel (1.0 Beta)
=============================================

PR�REQUIS :
	- Java SE (au moins Java SE 8)
	- Texmod
	- Si le fichier texmod est plac� dans un dossier prot�g�, il faut pouvoir lancer en mode admin (un .bat peut tr�s bien faire l'affaire, vous pouvez lancer ce type de fichier en mode admin, et cela "propagera" les autorisations � Java)

Une capture d'�cran (Tuto JSON.PNG) vous indiquera comment personnaliser vos checkpoints. ^^

Enjoy ! :)